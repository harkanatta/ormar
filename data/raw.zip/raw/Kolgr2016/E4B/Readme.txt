Stórt grjót með þara eða campanulariidae. Stórir pálburstar af pectinaria. Kíkja betur á amphipoda. Tvær bivalvia, önnur brotin, hin 0,7 mm.
Þekki almennt hvorki haus né sporð á nemertea, oligochaeta er oft tæpt líka. Tubificoides er nokkuð öruggur.
