Stórt grjót með þara eða campanulariidae. Stórir pálburstar af pectinaria. Kíkja betur á amphipoda. Tvær bivalvia, önnur brotin, hin 0,7 mm.
