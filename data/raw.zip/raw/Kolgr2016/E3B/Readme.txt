kíkja á Heteromastus filiformis og Mediomastus fragilis. Kannski er mest af þessu Mediomastus.
