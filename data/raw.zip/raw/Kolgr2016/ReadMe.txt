Botnsýni úr Kolgrafafirði 2016.
Botndýr í seti.
Árgangar allir greindir af GVH nema þessi árgangur.
Greinandi, Valtýr Sigurðsson, BioPol ehf.

Dálkar í gögnum:
Flokkun: tegundaheiti, fjölskyla eða ætt. Greint eins nærri tegund og ég treysti mér til.
N: fjöldi.
skipting: Hlutsýni eða heilt sýni. Ef talið er úr hlutsýni þarf að margfalda fundinn með nefnaranum í skiptingunni, t.d. ef dýr er talið úr skiptingunni 1/4 þarf að margfalda með fjórum. Ef talið er beint úr óskiptu sýni er ekki skalað/margfaldað
ath: Hér eru athugasemdir mínar. Oft er ég óviss um greiningu, stundum set ég inn hlekk á greiningarlykla o.s.frv.

Athugasemdir: Götungar eru teknir frá og taldir, bivalvia líka. Ekki greint frekar að sinni. Nemertea og eru í rugli platyhelminthes. Nematoda og oligochaeta  ónákvæmt.