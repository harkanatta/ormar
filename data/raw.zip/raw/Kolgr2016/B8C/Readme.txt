Bivalvia ekki greint (4 fundust síðar í stórri kúfskel ein af þeim er nuculana og ein brotin vesenisskel). Einn mjög heill ormur með keilulaga haus en engin tálkn, líklega Scolecida, merktur polychaeta. Annar ormur, frekar svipaður, með skrýtinn haus (líklega munnur úti og fixeraðist skringilega) settur í sama glas og merktur polychaeta.

