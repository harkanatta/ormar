Virðist illa fixerað. Á loki stóð „1/4 úr sýni“ en á miða í dollunni stóð að þetta væri týnt úr fyrir skiptingu en svo eru litlir steinar í þessu. Ef þetta er hlutsýni þá er skiljanlegt að ýmislegt slæðist með en ef þetta er týnt úr fyrir skiptingu þá þýðir það að steinarnir hafi verið valdir úr sem er ósennilegt.
Margir skemmdir ormar.
GVH merkir Maldane sarsi en skráir það ekki (E4a 2017, týnt út fyrir skiptingu)
Einn ormur var merktur polychaeta í glasi en er juvenile af Terebellomorpha í talningarskjalinu.

athugasemd í tanlningarskjali: „ekki viss, stendur týnt úr sýni og ¼“